CyberShield - HTML/CSS Cybersecurity Website
================================================
Files:
- index.html       Home
- about.html       About cybersecurity
- threats.html     Common cyber threats
- safety.html      Online safety tips
- password.html    Password security
- phishing.html    Phishing awareness
- contact.html     Contact form
- style.css        Shared stylesheet

How to run:
1. Extract the folder.
2. Open index.html in a browser.
3. All pages are connected through the navigation bar.

Note: This is a front-end demo. The contact form has no backend and does not actually send messages.
No JavaScript is used.
